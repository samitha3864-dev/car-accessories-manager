CAR ACCESSORIES PROFESSIONAL MANAGER

1. Open Command Prompt in this folder.
2. Install packages:
   py -m pip install -r requirements.txt
3. Start:
   py app.py
4. Open:
   http://127.0.0.1:5000/

Pages:
- New Entry
- Dashboard
- Customer Details
- Image Import (OCR in browser; internet is required the first time for CDN scripts)
- Import Excel with preview
- Products
- Analytics
- Download Excel

Data is stored in data/products.xlsx and data/website_data.json.
Do not delete the data folder if you want to keep saved records.
