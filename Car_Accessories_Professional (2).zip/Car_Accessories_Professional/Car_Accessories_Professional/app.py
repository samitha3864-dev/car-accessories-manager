from flask import Flask, render_template, request, jsonify, send_file
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from pathlib import Path
from datetime import datetime, date as date_type
from calendar import month_name
import json
import shutil
import tempfile

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
DATA_FILE = DATA_DIR / "website_data.json"
EXCEL_FILE = DATA_DIR / "products.xlsx"

MONTHS = [month_name[i] for i in range(1, 13)]

DEFAULT_CATEGORIES = [
    "Seat Cover", "Floor Mat / Mat", "Rubber Coating", "Interior Rubber Coating",
    "Steering Cover", "Sunfilm", "Door Visor", "Wheel Cup", "Mud Flap",
    "Skin / Sponge / Foamcoat", "Anti Chikmat / Perfume", "Horn", "Fog Lamp",
    "Cleaning / Interior-Exterior Service", "Other"
]

DEFAULT_PRODUCTS = {
    "Seat Cover": ["seat cover"],
    "Floor Mat / Mat": ["IXF Mat", "Floor Mat", "Engine Mat", "Noodies Mat"],
    "Rubber Coating": ["Rubber Coating"],
    "Interior Rubber Coating": ["Interior Rubber Coating"],
    "Steering Cover": ["Steering Cover"],
    "Sunfilm": ["Sunfilm", "Side Ceramic Shield", "Front Ceramic Shield"],
    "Door Visor": ["Door Visor"],
    "Wheel Cup": ["Wheel Cup"],
    "Mud Flap": ["Mud Flap", "Mud Flap OE", "Mud Flap Rubbee"],
    "Skin / Sponge / Foamcoat": ["Skin / Sponge / Foamcoat", "Cloth", "Double Side Cloth"],
    "Anti Chikmat / Perfume": ["Anti Chikmat", "Car Perfume"],
    "Horn": ["Roots Horn", "Rev. Horn"],
    "Fog Lamp": ["Fog Lamp", "Fog Lamp Toreto Harmo 120W", "HIL Bulb 180W"],
    "Cleaning / Interior-Exterior Service": [
        "Door Clean", "Interior Cleaning", "Exterior Cleaning", "Rubbing Polish",
        "Teflon Polish", "H/C Doom Polish", "Alignment", "Electrician Labour"
    ],
    "Other": []
}


def clean_name(value):
    return " ".join(str(value or "").strip().split())


def norm(value):
    return clean_name(value).casefold()


def default_data():
    return {"categories": DEFAULT_CATEGORIES[:], "products": {k: v[:] for k, v in DEFAULT_PRODUCTS.items()}}


def save_data(data):
    DATA_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def normalize_data(data):
    changed = False
    if not isinstance(data, dict):
        data, changed = default_data(), True
    categories = data.get("categories") if isinstance(data.get("categories"), list) else []
    products = data.get("products") if isinstance(data.get("products"), dict) else {}
    if not categories:
        categories = DEFAULT_CATEGORIES[:]
        changed = True
    cleaned_categories, seen_categories = [], set()
    for category in categories:
        category = clean_name(category)
        key = norm(category)
        if not category or key in seen_categories:
            changed = True
            continue
        seen_categories.add(key)
        cleaned_categories.append(category)
    final_products = {}
    for category in cleaned_categories:
        source = None
        if category in products and isinstance(products[category], list):
            source = products[category]
        else:
            for old_category, values in products.items():
                if norm(old_category) == norm(category) and isinstance(values, list):
                    source = values
                    break
        if source is None:
            source = DEFAULT_PRODUCTS.get(category, [])[:]
            changed = True
        if not source and category in DEFAULT_PRODUCTS and DEFAULT_PRODUCTS[category]:
            source = DEFAULT_PRODUCTS[category][:]
            changed = True
        out, seen_products = [], set()
        for product in source:
            product = clean_name(product)
            key = norm(product)
            if not product or key in seen_products:
                changed = True
                continue
            seen_products.add(key)
            out.append(product)
        final_products[category] = out
        if len(out) != len(source):
            changed = True
    if set(products.keys()) != set(final_products.keys()):
        changed = True
    result = {"categories": cleaned_categories, "products": final_products}
    return result, changed


def load_data():
    if not DATA_FILE.exists():
        data = default_data()
        save_data(data)
        return data
    try:
        raw = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except Exception:
        raw = default_data()
    data, changed = normalize_data(raw)
    if changed:
        save_data(data)
    return data


def product_headers(data):
    return [(category, product) for category in data["categories"] for product in data["products"].get(category, [])]


def style_headers(ws, total_col):
    top_fill = PatternFill("solid", fgColor="1F4E78")
    sub_fill = PatternFill("solid", fgColor="D9EAF7")
    thin = Side(style="thin", color="B7B7B7")
    for row in ws.iter_rows(min_row=1, max_row=2, min_col=1, max_col=total_col):
        for cell in row:
            cell.font = Font(bold=True, color="FFFFFF" if cell.row == 1 else "000000")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.fill = top_fill if cell.row == 1 else sub_fill
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws.row_dimensions[1].height = 30
    ws.row_dimensions[2].height = 48
    for col, width in {1: 14, 2: 24, 3: 18, 4: 20}.items():
        ws.column_dimensions[get_column_letter(col)].width = width
    for col in range(5, total_col + 1):
        ws.column_dimensions[get_column_letter(col)].width = 22


def make_sheet(wb, sheet_name, data):
    if sheet_name in wb.sheetnames:
        return wb[sheet_name]
    ws = wb.create_sheet(sheet_name)
    fixed = ["Date", "Customer Name", "Mobile Number", "Vehicle Number"]
    headers = product_headers(data)
    total_col = 5 + len(headers)
    for col, title in enumerate(fixed, 1):
        ws.merge_cells(start_row=1, start_column=col, end_row=2, end_column=col)
        ws.cell(1, col).value = title
    col = 5
    for category in data["categories"]:
        products = data["products"].get(category, [])
        if not products:
            continue
        start, end = col, col + len(products) - 1
        ws.merge_cells(start_row=1, start_column=start, end_row=1, end_column=end)
        ws.cell(1, start).value = category
        for product in products:
            ws.cell(2, col).value = product
            col += 1
    ws.merge_cells(start_row=1, start_column=total_col, end_row=2, end_column=total_col)
    ws.cell(1, total_col).value = "Total Amount"
    style_headers(ws, total_col)
    ws.freeze_panes = "E3"
    return ws


def make_workbook(data):
    wb = Workbook()
    ws = wb.active
    ws.title = "Customer Entries"
    # Legacy sheet is intentionally kept for old data. New records go to month sheets.
    make_sheet(wb, "Customer Entries", data)
    return wb, ws


def excel_product_columns(ws):
    lookup = []
    current_category = ""
    for col in range(5, ws.max_column):
        category_value = ws.cell(1, col).value
        if category_value not in (None, ""):
            text = clean_name(category_value)
            if norm(text) != norm("Total Amount"):
                current_category = text
        product = clean_name(ws.cell(2, col).value)
        if not product:
            continue
        lookup.append((col, current_category or "Other", product))
    return lookup


def parse_date(value, fallback=None):
    if isinstance(value, datetime):
        return value.strftime("%d-%m-%Y")
    if isinstance(value, date_type):
        return value.strftime("%d-%m-%Y")
    text = clean_name(value)
    if text:
        for fmt in ("%d-%m-%Y", "%d/%m/%Y", "%d.%m.%Y", "%Y-%m-%d", "%m/%d/%Y"):
            try:
                return datetime.strptime(text, fmt).strftime("%d-%m-%Y")
            except ValueError:
                pass
    if fallback:
        return fallback
    return ""


def date_obj(value):
    try:
        return datetime.strptime(parse_date(value), "%d-%m-%Y")
    except Exception:
        return datetime.max


def month_for_date(value):
    parsed = parse_date(value)
    try:
        month_number = datetime.strptime(parsed, "%d-%m-%Y").month
        return month_name[month_number]
    except Exception:
        return None


def month_sheet_name(value):
    m = month_for_date(value)
    return m or "Other"


def safe_value(value):
    value = clean_name(value)
    return value if value else "nil"


def numeric_quantity(value):
    if value in (None, "", 0, "0", 0.0):
        return 0
    try:
        return float(value)
    except Exception:
        return 0


def add_missing_catalog_items(items):
    """Add imported product/category names to the website catalogue without deleting anything."""
    data = load_data()
    changed = False
    for category, product in items:
        category = clean_name(category) or "Other"
        product = clean_name(product)
        actual_cat = next((c for c in data["categories"] if norm(c) == norm(category)), None)
        if not actual_cat:
            data["categories"].append(category)
            data["products"][category] = []
            actual_cat = category
            changed = True
        if product and not any(norm(p) == norm(product) for p in data["products"].get(actual_cat, [])):
            data["products"].setdefault(actual_cat, []).append(product)
            changed = True
    if changed:
        save_data(data)
    return data, changed


def read_sheet_rows(ws, sheet_name):
    product_columns = excel_product_columns(ws)
    catalog = load_data()
    catalog_map = {}
    for cat in catalog.get("categories", []):
        for prod in catalog.get("products", {}).get(cat, []):
            catalog_map.setdefault(norm(prod), cat)
    rows = []
    for row in range(3, ws.max_row + 1):
        vals = [ws.cell(row, c).value for c in range(1, min(5, ws.max_column) + 1)]
        if all(v in (None, "") for v in vals):
            continue
        date_value = parse_date(ws.cell(row, 1).value)
        name = ws.cell(row, 2).value or "nil"
        mobile = ws.cell(row, 3).value or "nil"
        vehicle = ws.cell(row, 4).value or "nil"
        products = []
        for col, category, product in product_columns:
            q = numeric_quantity(ws.cell(row, col).value)
            if q:
                category = category or catalog_map.get(norm(product), "Other")
                products.append({"category": category, "product": product, "quantity": q})
        total = ws.cell(row, ws.max_column).value or 0
        rows.append({
            "excel_row": row,
            "sheet": sheet_name,
            "date": date_value,
            "name": name,
            "mobile": mobile,
            "vehicle": vehicle,
            "total_amount": total,
            "products": products
        })
    return rows


def read_all_rows():
    if not EXCEL_FILE.exists():
        return []
    try:
        wb = load_workbook(EXCEL_FILE, data_only=True)
        rows = []
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            if ws.max_row < 3 or clean_name(ws.cell(1, 1).value).casefold() != "date":
                continue
            rows.extend(read_sheet_rows(ws, sheet_name))
        wb.close()
        rows.sort(key=lambda x: (date_obj(x.get("date")), x.get("excel_row", 0)))
        return rows
    except Exception as exc:
        print("Excel read error:", exc)
        return []


def read_existing_rows():
    # Backward-compatible name used by older code/workflows.
    return read_all_rows()


def rebuild_excel_preserving_rows():
    """Rebuild only after catalogue changes, preserving all records and their month sheets."""
    old_rows = read_all_rows()
    data = load_data()
    wb = Workbook()
    wb.remove(wb.active)
    make_sheet(wb, "Customer Entries", data)
    # Preserve monthly sheets for all existing records.
    for record in old_rows:
        target = month_sheet_name(record.get("date"))
        if target == "Other":
            target = "Customer Entries"
        if target not in wb.sheetnames:
            make_sheet(wb, target, data)
        append_record_to_sheet(wb[target], record, data)
    reorder_sheets(wb)
    wb.save(EXCEL_FILE)


def ensure_excel():
    if not EXCEL_FILE.exists():
        wb, _ = make_workbook(load_data())
        wb.save(EXCEL_FILE)


def append_record_to_sheet(ws, record, data):
    headers = product_headers(data)
    lookup = {(norm(c), norm(p)): 5 + i for i, (c, p) in enumerate(headers)}
    row = [record.get("date", ""), record.get("name", "nil"), record.get("mobile", "nil"), record.get("vehicle", "nil")]
    row += [0] * len(headers)
    row += [record.get("total_amount") or 0]
    for item in record.get("products", []):
        key = (norm(item.get("category")), norm(item.get("product")))
        if key in lookup:
            row[lookup[key] - 1] = item.get("quantity", 0)
    ws.append(row)
    for cell in ws[ws.max_row]:
        cell.alignment = Alignment(horizontal="center", vertical="center")
    return ws.max_row


def reorder_sheets(wb):
    order = {"Customer Entries": -1}
    for i, m in enumerate(MONTHS):
        order[m] = i
    wb._sheets.sort(key=lambda ws: order.get(ws.title, 100))


def ensure_month_sheet(wb, month):
    data = load_data()
    if month not in MONTHS:
        raise ValueError("Invalid month")
    if month not in wb.sheetnames:
        make_sheet(wb, month, data)
    reorder_sheets(wb)
    return wb[month]


def valid_date(value):
    value = clean_name(value) or datetime.now().strftime("%d-%m-%Y")
    parsed = parse_date(value)
    if not parsed:
        raise ValueError("Date must be in DD-MM-YYYY format. Example: 15-09-2026")
    return parsed


def find_record_sheet_row(sheet, row):
    if not EXCEL_FILE.exists():
        return None, None
    wb = load_workbook(EXCEL_FILE)
    if sheet not in wb.sheetnames:
        wb.close(); return None, None
    ws = wb[sheet]
    if row < 3 or row > ws.max_row:
        wb.close(); return None, None
    return wb, ws



@app.route("/image-import")
def image_import():
    return render_template("image_import.html")

@app.route("/excel-import")
def excel_import_page():
    return render_template("excel_import.html")

@app.route("/products")
def products_page():
    return render_template("products.html")

@app.route("/analytics")
def analytics_page():
    return render_template("analytics.html")


def parse_uploaded_excel(upload):
    if not upload or not upload.filename or not upload.filename.lower().endswith((".xlsx", ".xlsm")):
        raise ValueError("Please select an .xlsx or .xlsm Excel file.")
    with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
        path = Path(tmp.name); upload.save(path)
    try:
        source = load_workbook(path, data_only=True); imported=[]; catalog_items=[]
        for source_name in source.sheetnames:
            ws=source[source_name]
            if ws.max_row < 3 or clean_name(ws.cell(1,1).value).casefold() != "date": continue
            columns=excel_product_columns(ws)
            catalog_items += [(cat or "Other",prod) for _,cat,prod in columns]
            for row in range(3,ws.max_row+1):
                if all(ws.cell(row,c).value in (None,"") for c in range(1,5)): continue
                d=parse_date(ws.cell(row,1).value)
                if not d: continue
                products=[]
                for col,cat,prod in columns:
                    q=numeric_quantity(ws.cell(row,col).value)
                    if q: products.append({"category":cat or "Other","product":prod,"quantity":q})
                total=ws.cell(row,ws.max_column).value or 0
                try: total=float(total)
                except: total=0
                imported.append({"date":d,"name":safe_value(ws.cell(row,2).value),"mobile":safe_value(ws.cell(row,3).value),"vehicle":safe_value(ws.cell(row,4).value),"total_amount":total,"products":products})
        source.close(); return imported,catalog_items
    finally:
        path.unlink(missing_ok=True)

@app.post("/api/preview-excel")
def preview_excel():
    try:
        records,_=parse_uploaded_excel(request.files.get("file"))
        if not records: return jsonify(success=False,message="No compatible customer rows found."),400
        return jsonify(success=True,records=records)
    except Exception as exc: return jsonify(success=False,message=str(exc)),400

@app.post("/api/import-excel-preview")
def import_excel_preview():
    records=(request.get_json(silent=True) or {}).get("records") or []
    if not records: return jsonify(success=False,message="No records selected."),400
    try:
        catalog_items=[(p.get("category") or "Other",p.get("product")) for r in records for p in r.get("products",[])]
        data,catalog_changed=add_missing_catalog_items(catalog_items)
        if catalog_changed: rebuild_excel_preserving_rows()
        ensure_excel(); wb=load_workbook(EXCEL_FILE); existing=read_all_rows()
        def fp(r): return (r.get("date",""),norm(r.get("name")),norm(r.get("mobile")),norm(r.get("vehicle")),str(r.get("total_amount") or 0),tuple(sorted((norm(p.get("category")),norm(p.get("product")),str(p.get("quantity"))) for p in r.get("products",[]))))
        seen={fp(r) for r in existing}; added=skipped=0
        for r in records:
            if fp(r) in seen: skipped+=1; continue
            ws=ensure_month_sheet(wb,month_sheet_name(r["date"])); append_record_to_sheet(ws,r,data); seen.add(fp(r)); added+=1
        reorder_sheets(wb); wb.save(EXCEL_FILE); wb.close()
        return jsonify(success=True,message=f"Imported {added} record(s). {skipped} duplicate(s) skipped.",imported=added,skipped=skipped)
    except Exception as exc: return jsonify(success=False,message=f"Import failed: {exc}"),400

@app.get("/api/analytics")
def analytics_data():
    rows = read_all_rows()

    customer_counts = {}
    customer_info = {}
    daily_sales = {}
    product_counts = {}
    vehicle_set = set()

    # -----------------------------
    # PROCESS CUSTOMER DATA
    # -----------------------------
    for r in rows:
        name = clean_name(r.get("name")) or "Nil"
        mobile = clean_name(r.get("mobile")) or "Nil"

        # Mobile is primary customer identifier
        if mobile.casefold() not in ("nil", "", "none"):
            customer_key = f"mobile:{norm(mobile)}"
        else:
            customer_key = f"name:{norm(name)}"

        customer_counts[customer_key] = (
            customer_counts.get(customer_key, 0) + 1
        )

        customer_info[customer_key] = {
            "name": name,
            "mobile": mobile
        }

        # -----------------------------
        # DAILY SALES / PROFIT
        # -----------------------------
        d = r.get("date") or ""

        try:
            amount = float(r.get("total_amount") or 0)
        except (TypeError, ValueError):
            amount = 0.0

        if d:
            daily_sales[d] = daily_sales.get(d, 0) + amount

        # -----------------------------
        # VEHICLE
        # -----------------------------
        vehicle = norm(r.get("vehicle"))

        if vehicle and vehicle != "nil":
            vehicle_set.add(vehicle)

        # -----------------------------
        # PRODUCTS
        # -----------------------------
        for p in r.get("products", []):
            product = clean_name(p.get("product"))

            if not product:
                continue

            try:
                quantity = float(p.get("quantity") or 0)
            except (TypeError, ValueError):
                quantity = 0

            product_counts[product] = (
                product_counts.get(product, 0) + quantity
            )

    # -----------------------------
    # REPEAT CUSTOMERS
    # -----------------------------
    repeat_customers = []

    for key, count in customer_counts.items():
        if count > 1:
            info = customer_info.get(key, {})

            repeat_customers.append({
                "name": info.get("name", "Nil"),
                "mobile": info.get("mobile", "Nil"),
                "visits": count
            })

    # Highest repeat visits first
    repeat_customers.sort(
        key=lambda x: x["visits"],
        reverse=True
    )

    # -----------------------------
    # DAILY DATA
    # -----------------------------
    days = sorted(
        daily_sales.keys(),
        key=date_obj
    )

    daily_data = []

    for d in days:
        daily_data.append({
            "date": d,
            "amount": round(daily_sales[d], 2)
        })

    # -----------------------------
    # TOP PRODUCTS
    # -----------------------------
    top_products = sorted(
        product_counts.items(),
        key=lambda x: x[1],
        reverse=True
    )[:10]

    # -----------------------------
    # UNSOLD PRODUCTS
    # -----------------------------
    data = load_data()

    all_products = [
        product
        for category in data["categories"]
        for product in data["products"].get(category, [])
    ]

    sold_products = {
        norm(product)
        for product, quantity in product_counts.items()
        if quantity > 0
    }

    unsold_products = [
        product
        for product in all_products
        if norm(product) not in sold_products
    ]

    return jsonify({
        "repeat_customers": repeat_customers,

        "repeat_customer_count": len(repeat_customers),

        "one_time_customers": sum(
            1 for count in customer_counts.values()
            if count == 1
        ),

        "repeat_products": sum(
            1 for quantity in product_counts.values()
            if quantity > 1
        ),

        "unique_vehicles": len(vehicle_set),

        "daily_data": daily_data,

        "daily_labels": days,

        "daily_sales": [
            round(daily_sales[d], 2)
            for d in days
        ],

        "top_products": [
            {
                "name": name,
                "quantity": round(quantity, 2)
            }
            for name, quantity in top_products
        ],

        "unsold_products": unsold_products
    })
    rows=read_all_rows(); customer_counts={}; daily={}; product_counts={}; vehicle_set=set()
    for r in rows:
        key=norm(r.get("mobile")) or norm(r.get("name"))
        if key: customer_counts[key]=customer_counts.get(key,0)+1
        d=r.get("date") or ""; daily[d]=daily.get(d,0)+float(r.get("total_amount") or 0)
        v=norm(r.get("vehicle"));
        if v and v!="nil": vehicle_set.add(v)
        for p in r.get("products",[]): product_counts[p.get("product")]=product_counts.get(p.get("product"),0)+float(p.get("quantity") or 0)
    repeat=sum(1 for v in customer_counts.values() if v>1); one=sum(1 for v in customer_counts.values() if v==1)
    all_products=[p for c in load_data()["categories"] for p in load_data()["products"].get(c,[])]
    sold_keys={norm(k) for k,v in product_counts.items() if v}; unsold=[p for p in all_products if norm(p) not in sold_keys]
    days=sorted(daily,key=date_obj); top=sorted(product_counts.items(),key=lambda x:x[1],reverse=True)[:10]
    return jsonify(repeat_customers=repeat,one_time_customers=one,repeat_products=sum(1 for v in product_counts.values() if v>1),unique_vehicles=len(vehicle_set),daily_labels=days,daily_sales=[round(daily[d],2) for d in days],top_products=[{"name":k,"quantity":round(v,2)} for k,v in top],unsold_products=unsold)

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/customer-details")
def customer_details():
    return render_template("customer_details.html")


@app.get("/api/data")
def api_data():
    return jsonify(load_data())


@app.get("/api/months")
def api_months():
    return jsonify(success=True, months=MONTHS, current=datetime.now().strftime("%B"))


@app.post("/api/category")
def add_category():
    data = load_data(); body = request.get_json(silent=True) or {}; category = clean_name(body.get("category"))
    if not category: return jsonify(success=False, message="Category name is required."), 400
    if any(norm(c) == norm(category) for c in data["categories"]): return jsonify(success=False, message="Category already exists."), 409
    data["categories"].append(category); data["products"][category] = []; save_data(data); rebuild_excel_preserving_rows()
    return jsonify(success=True, data=data, message="Category added successfully.")


@app.delete("/api/category/<path:category>")
def delete_category(category):
    data = load_data(); actual = next((c for c in data["categories"] if norm(c) == norm(category)), None)
    if not actual: return jsonify(success=False, message="Category not found."), 404
    data["categories"].remove(actual); data["products"].pop(actual, None); save_data(data); rebuild_excel_preserving_rows()
    return jsonify(success=True, data=data, message="Category deleted successfully.")


@app.post("/api/product")
def add_product():
    data = load_data(); body = request.get_json(silent=True) or {}; category = clean_name(body.get("category")); product = clean_name(body.get("product"))
    if not category or not product: return jsonify(success=False, message="Category and product name are required."), 400
    actual = next((c for c in data["categories"] if norm(c) == norm(category)), None)
    if not actual: return jsonify(success=False, message="Category not found."), 404
    if any(norm(p) == norm(product) for p in data["products"].get(actual, [])): return jsonify(success=False, message=f'Product "{product}" already exists in {actual}.'), 409
    data["products"].setdefault(actual, []).append(product); save_data(data); rebuild_excel_preserving_rows()
    return jsonify(success=True, data=data, message="New product added successfully.")


@app.delete("/api/product")
def delete_product():
    data = load_data(); body = request.get_json(silent=True) or {}; category = clean_name(body.get("category")); product = clean_name(body.get("product"))
    actual = next((c for c in data["categories"] if norm(c) == norm(category)), None)
    if not actual: return jsonify(success=False, message="Category not found."), 404
    products = data["products"].get(actual, []); existing = next((p for p in products if norm(p) == norm(product)), None)
    if not existing: return jsonify(success=False, message="Product not found."), 404
    products.remove(existing); save_data(data); rebuild_excel_preserving_rows()
    return jsonify(success=True, data=data, message="Product deleted successfully.")


@app.post("/api/remove-duplicates")
def remove_duplicates():
    data = load_data(); changed = False; seen_global = set()
    for category in data["categories"]:
        old = data["products"].get(category, []); new = []
        for product in old:
            key = norm(product)
            if key and key not in seen_global:
                seen_global.add(key); new.append(clean_name(product))
            else:
                changed = True
        if new != old: changed = True
        data["products"][category] = new
    if changed: save_data(data); rebuild_excel_preserving_rows()
    return jsonify(success=True, changed=changed, data=data, message="Duplicate products removed globally." if changed else "No duplicate products found.")


@app.get("/api/customers")
def customers():
    rows = read_all_rows()

    # Count visits for each customer
    # Mobile number is the main identifier.
    # If mobile is Nil/empty, customer name is used.
    customer_counts = {}

    for row in rows:
        name = clean_name(row.get("name")) or "Nil"
        mobile = clean_name(row.get("mobile")) or "Nil"

        if mobile.casefold() not in ("nil", "", "none"):
            key = f"mobile:{norm(mobile)}"
        else:
            key = f"name:{norm(name)}"

        customer_counts[key] = customer_counts.get(key, 0) + 1

    # Add repeat customer information to every row
    for i, row in enumerate(rows, 1):
        name = clean_name(row.get("name")) or "Nil"
        mobile = clean_name(row.get("mobile")) or "Nil"

        if mobile.casefold() not in ("nil", "", "none"):
            key = f"mobile:{norm(mobile)}"
        else:
            key = f"name:{norm(name)}"

        visit_count = customer_counts.get(key, 1)

        row["display_no"] = i
        row["customer_name"] = name
        row["phone_number"] = mobile
        row["visit_count"] = visit_count
        row["is_repeat_customer"] = visit_count > 1

        if visit_count > 1:
            row["repeat_label"] = f"Repeat Customer • {visit_count} visits"
        else:
            row["repeat_label"] = "New / One-time Customer"

    return jsonify(
        success=True,
        customers=rows
    )


@app.post("/api/save-customer")
def save_customer():
    body = request.get_json(silent=True) or {}; customer = body.get("customer") or {}; selections = body.get("products") or []
    try: date = valid_date(customer.get("date"))
    except ValueError as exc: return jsonify(success=False, message=str(exc)), 400
    name, mobile, vehicle = safe_value(customer.get("name")), safe_value(customer.get("mobile")), safe_value(customer.get("vehicle"))
    if not selections: return jsonify(success=False, message="Please add at least one product type."), 400
    try: total = float(customer.get("total_amount") or 0)
    except Exception: total = 0
    ensure_excel(); wb = load_workbook(EXCEL_FILE); data = load_data(); month = month_sheet_name(date)
    ws = ensure_month_sheet(wb, month)
    record = {"date": date, "name": name, "mobile": mobile, "vehicle": vehicle, "total_amount": total, "products": selections}
    append_record_to_sheet(ws, record, data); reorder_sheets(wb); wb.save(EXCEL_FILE); wb.close()
    return jsonify(success=True, message=f"Customer entry saved in {month} sheet.")


@app.put("/api/customer/<path:sheet>/<int:excel_row>")
def update_customer(sheet, excel_row):
    body = request.get_json(silent=True) or {}; customer = body.get("customer") or {}; selections = body.get("products") or []
    try: date = valid_date(customer.get("date"))
    except ValueError as exc: return jsonify(success=False, message=str(exc)), 400
    if not selections: return jsonify(success=False, message="Please add at least one product type."), 400
    if not EXCEL_FILE.exists(): return jsonify(success=False, message="Excel file not found."), 404
    wb = load_workbook(EXCEL_FILE); data = load_data()
    if sheet not in wb.sheetnames:
        wb.close(); return jsonify(success=False, message="Customer record not found."), 404
    old_ws = wb[sheet]
    if excel_row < 3 or excel_row > old_ws.max_row:
        wb.close(); return jsonify(success=False, message="Customer record not found."), 404
    record = {"date": date, "name": safe_value(customer.get("name")), "mobile": safe_value(customer.get("mobile")), "vehicle": safe_value(customer.get("vehicle")), "total_amount": float(customer.get("total_amount") or 0), "products": selections}
    target = month_sheet_name(date)
    # Update in place when month is unchanged. If month changes, remove old row and append to new month.
    if target == sheet:
        # Clear product cells but keep headers.
        for col in range(1, old_ws.max_column + 1): old_ws.cell(excel_row, col).value = 0
        old_ws.cell(excel_row, 1).value = record["date"]; old_ws.cell(excel_row, 2).value = record["name"]; old_ws.cell(excel_row, 3).value = record["mobile"]; old_ws.cell(excel_row, 4).value = record["vehicle"]
        lookup = {(norm(c), norm(p)): 5+i for i,(c,p) in enumerate(product_headers(data))}
        for item in selections:
            key=(norm(item.get("category")), norm(item.get("product")))
            if key in lookup: old_ws.cell(excel_row, lookup[key]).value = numeric_quantity(item.get("quantity"))
        old_ws.cell(excel_row, old_ws.max_column).value = record["total_amount"]
    else:
        old_ws.delete_rows(excel_row, 1)
        target_ws = ensure_month_sheet(wb, target)
        append_record_to_sheet(target_ws, record, data)
    reorder_sheets(wb); wb.save(EXCEL_FILE); wb.close()
    return jsonify(success=True, message="Customer updated successfully.")


@app.delete("/api/customer/<path:sheet>/<int:excel_row>")
def delete_customer(sheet, excel_row):
    if not EXCEL_FILE.exists(): return jsonify(success=False, message="Excel file not found."), 404
    wb = load_workbook(EXCEL_FILE)
    if sheet not in wb.sheetnames: wb.close(); return jsonify(success=False, message="Customer not found."), 404
    ws = wb[sheet]
    if excel_row < 3 or excel_row > ws.max_row: wb.close(); return jsonify(success=False, message="Customer not found."), 404
    ws.delete_rows(excel_row, 1); wb.save(EXCEL_FILE); wb.close()
    return jsonify(success=True, message="Customer deleted successfully.")


@app.post("/api/import-excel")
def import_excel():
    upload = request.files.get("file")
    if not upload or not upload.filename:
        return jsonify(success=False, message="Please select an Excel file."), 400
    if not upload.filename.lower().endswith((".xlsx", ".xlsm")):
        return jsonify(success=False, message="Please select an .xlsx or .xlsm Excel file."), 400
    ensure_excel()
    with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
        temp_path = Path(tmp.name)
        upload.save(temp_path)
    try:
        source = load_workbook(temp_path, data_only=True)
        imported = []
        catalog_items = []
        for source_name in source.sheetnames:
            ws = source[source_name]
            if ws.max_row < 3: continue
            if clean_name(ws.cell(1,1).value).casefold() != "date": continue
            columns = excel_product_columns(ws)
            for _, cat, prod in columns:
                catalog_items.append((cat or "Other", prod))
            # If a sheet is named as a month, use it only as fallback for rows with a missing year/date.
            fallback = None
            if source_name in MONTHS:
                fallback = source_name
            for row in range(3, ws.max_row + 1):
                if all(ws.cell(row,c).value in (None, "") for c in range(1,5)): continue
                d = parse_date(ws.cell(row,1).value)
                if not d and fallback:
                    # Do not invent a day; skip rows without a real date.
                    continue
                if not d: continue
                products=[]
                for col,cat,prod in columns:
                    q=numeric_quantity(ws.cell(row,col).value)
                    if q: products.append({"category":cat or "Other","product":prod,"quantity":q})
                total=ws.cell(row,ws.max_column).value or 0
                try: total=float(total)
                except Exception: total=0
                imported.append({"date":d,"name":safe_value(ws.cell(row,2).value),"mobile":safe_value(ws.cell(row,3).value),"vehicle":safe_value(ws.cell(row,4).value),"total_amount":total,"products":products})
        source.close()
        if not imported:
            return jsonify(success=False, message="No compatible customer rows found. Expected Date in column A and product quantities in the same format."), 400
        data, catalog_changed = add_missing_catalog_items(catalog_items)
        # If imported Excel contains a new product/category, rebuild the existing
        # month sheets first so their headers match the updated catalogue.
        if catalog_changed:
            rebuild_excel_preserving_rows()
        wb = load_workbook(EXCEL_FILE)
        existing = read_all_rows()
        def fingerprint(record):
            products = tuple(sorted((norm(p.get("category")), norm(p.get("product")), str(p.get("quantity"))) for p in record.get("products", [])))
            return (record.get("date", ""), norm(record.get("name")), norm(record.get("mobile")), norm(record.get("vehicle")), str(record.get("total_amount") or 0), products)
        seen = {fingerprint(r) for r in existing}
        added = 0
        skipped = 0
        for record in imported:
            fp = fingerprint(record)
            if fp in seen:
                skipped += 1
                continue
            month = month_sheet_name(record["date"])
            ws = ensure_month_sheet(wb, month)
            append_record_to_sheet(ws, record, data)
            seen.add(fp)
            added += 1
        reorder_sheets(wb); wb.save(EXCEL_FILE); wb.close()
        message = f"Imported {added} customer record(s) successfully. Data added to month-wise sheets."
        if skipped:
            message += f" {skipped} duplicate record(s) skipped."
        return jsonify(success=True, imported=added, skipped=skipped, message=message)
    except Exception as exc:
        print("Import error:", exc)
        return jsonify(success=False, message=f"Excel import failed: {exc}"), 400
    finally:
        try: temp_path.unlink(missing_ok=True)
        except Exception: pass


@app.get("/download-excel")
def download_excel():
    ensure_excel()
    return send_file(EXCEL_FILE, as_attachment=True, download_name="Car_Accessories_Customer_Data.xlsx")


@app.post("/api/clear-excel")
def clear_excel():
    # Keep workbook structure and all month sheet headers, but clear customer rows.
    ensure_excel(); wb = load_workbook(EXCEL_FILE)
    for ws in wb.worksheets:
        if ws.max_row >= 3 and clean_name(ws.cell(1,1).value).casefold() == "date":
            ws.delete_rows(3, ws.max_row - 2)
    wb.save(EXCEL_FILE); wb.close()
    return jsonify(success=True, message="All Excel customer data cleared. Month sheets and catalogue were kept.")

# =========================
# DASHBOARD
# =========================

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.get("/api/dashboard")
def dashboard_data():
    rows = read_all_rows()

    total_customers = len(rows)
    total_sales = 0.0

    month_sales = {month: 0.0 for month in MONTHS}
    month_customers = {month: 0 for month in MONTHS}
    product_totals = {}

    for record in rows:
        try:
            amount = float(record.get("total_amount") or 0)
        except (TypeError, ValueError):
            amount = 0.0

        total_sales += amount

        month = month_for_date(record.get("date"))
        if month in month_sales:
            month_sales[month] += amount
            month_customers[month] += 1

        for item in record.get("products", []):
            product = clean_name(item.get("product"))
            if not product:
                continue

            try:
                quantity = float(item.get("quantity") or 0)
            except (TypeError, ValueError):
                quantity = 0.0

            if quantity:
                product_totals[product] = (
                    product_totals.get(product, 0.0) + quantity
                )

    month_labels = [
        month for month in MONTHS
        if month_customers.get(month, 0) > 0
    ]

    top_products = sorted(
        product_totals.items(),
        key=lambda item: item[1],
        reverse=True
    )[:10]

    return jsonify({
        "total_customers": total_customers,
        "total_sales": round(total_sales, 2),
        "active_months": len(month_labels),
        "products_used": len(product_totals),
        "month_labels": month_labels,
        "month_sales": [
            round(month_sales[month], 2)
            for month in month_labels
        ],
        "month_customers": [
            month_customers[month]
            for month in month_labels
        ],
        "top_products": [
            {
                "name": name,
                "quantity": round(quantity, 2)
            }
            for name, quantity in top_products
        ]
    })


# =========================
# START SERVER
# =========================

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
